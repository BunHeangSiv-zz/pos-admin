<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Sex;
use Illuminate\Support\Facades\Validator;

class CustomerController extends Controller
{

    public function index()
    {
        $customers = Customer::join('tblsex', 'tblcustomer.sexid', '=', 'tblsex.sexid')
            ->select('tblcustomer.*', 'tblsex.*') // Select all columns from both tables
            ->get();
        // dd($customers);
        return response()->json($customers, 200);
    }
    public function store(Request $request)
    {
        // dd(2);
        $validator = Validator::make($request->all(), [
            'customername' => 'required|string|max:255',
            'dob' => 'nullable|date',
            'sexid' => 'nullable|int',
            'statusid' => 'nullable|int',
            'address' => 'nullable|string|max:255',
            'phonenumber' => 'nullable|string|max:20',

        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $customer = Customer::create($request->all());

        return response()->json($customer, 201);
    }
    public function show($id)
    {
        $customer = Customer::find($id);
        if (!$customer) {
            return response()->json(['message' => 'Customer not found'], 404);
        }
        return response()->json($customer);
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::find($id);
        if (!$customer) {
            return response()->json(['message' => 'Customer not found'], 404);
        }
        $customer->update($request->all());
        return response()->json($customer);
    }

    public function destroy($id)
    {
        $customer = Customer::find($id);
        if (!$customer) {
            return response()->json(['message' => 'Customer not found'], 404);
        }
        $customer->delete();
        return response()->json(['message' => 'Customer deleted']);
    }
}
