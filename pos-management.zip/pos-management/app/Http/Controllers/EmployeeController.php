<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        // Eager load the sex and position relationships using the correct method names
        $employees = Employee::with(['sex:sexid,sexen', 'position:positionid,positionname'])->get();

        // Modify the collection to add the full URL for the photo
        $employees->each(function ($employee) {
            if ($employee->photo) {
                $employee->photo = asset('storage/' . $employee->photo);
            }
        });

        return response()->json($employees);
    }

    public function store(Request $request)
    {
        $request->validate([
            'employeename' => 'required',
            'dob' => 'required|date',
            'address' => 'required',
            'phonenumber' => 'required',
            'email' => 'required|email',
            'telegram' => 'required',
            'photo' => 'required|image',
            'statusid' => 'required|int'
        ]);

        if ($request->hasFile('photo') && $request->file('photo')->isValid()) {
            // Store the photo in the 'images' folder within 'public'
            $path = $request->photo->store('images', 'public');

            // Add the path to the request data
            $requestData = $request->all();
            $requestData['photo'] = $path;
        } else {
            return response()->json(['error' => 'Invalid or No File Uploaded'], 422);
        }

        $employee = Employee::create($requestData);
        return response()->json($employee, 201);
    }


    public function show($id)
    {
        $employee = Employee::find($id);
        if (!$employee) {
            return response()->json(['message' => 'Employee not found'], 404);
        }
        return response()->json($employee);
    }

    public function update(Request $request, $id)
    {
        $employee = Employee::find($id);
        if (!$employee) {
            return response()->json(['message' => 'Employee not found'], 404);
        }
        $employee->update($request->all());
        return response()->json($employee);
    }

    public function destroy($id)
    {
        $employee = Employee::find($id);
        if (!$employee) {
            return response()->json(['message' => 'Employee not found'], 404);
        }
        $employee->delete();
        return response()->json(['message' => 'Employee deleted']);
    }
}
