<?php
namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Employee;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\InventoryLog;
use App\Models\Product;
use App\Models\Status;
use Illuminate\Support\Facades\DB;
// use DB;

class OrderController extends Controller
{
    public function create()
    {
        $employees = Employee::all();
        $customers = Customer::all();
        $products = Product::all();
        $statuses = Status::all();  // Assuming you have a model for statuses
        return view('orders.create', compact('employees', 'customers', 'products', 'statuses'));
    }

    public function store(Request $request)
{
    $validated = $request->validate([
        'employeeid' => 'required|exists:tblemployee,employeeid',
        'customerid' => 'required|exists:tblcustomer,customerid',
        'productid.*' => 'required|exists:tblproduct,productid',
        'quantity.*' => 'required|integer|min:1',
        'unitprice.*' => 'required|numeric',
        'statusid' => 'required|exists:tblstatus,statusid'
    ]);

    DB::transaction(function () use ($request) {
        $order = new Order([
            'orderdate' => now(),
            'employeeid' => $request->employeeid,
            'customerid' => $request->customerid,
            'totalamount' => array_sum($request->unitprice),
            'statusid' => $request->statusid
        ]);
        $order->save();

        foreach ($request->productid as $index => $productid) {
            $quantity = $request->quantity[$index];
            $product = Product::find($productid);

            // Check if there's enough inventory
            if ($product->quantity < $quantity) {
                throw new \Exception("Not enough inventory for product ID: {$productid}");
            }

            // Update product quantity
            $product->quantity -= $quantity;
            $product->save();

            // Create order detail
            $order->details()->create([
                'productid' => $productid,
                'quantity' => $quantity,
                'unitprice' => $request->unitprice[$index],
                'statusid' => $request->statusid
            ]);
        }
    });

    return redirect()->route('orders.create')->with('success', 'Order created successfully');
}


    public function edit(Order $order)
    {
        return view('orders.edit', compact('order'));
    }

    public function update(Request $request, Order $order)
    {
        DB::transaction(function () use ($request, $order) {
            $order->update($request->all());
            $order->details()->delete(); // Assuming you want to replace all details
            foreach ($request->products as $product) {
                $order->details()->create($product);
            }
        });
        return redirect()->route('orders.edit', $order->id)->with('success', 'Order updated successfully');
    }

    public function updateStatus(Request $request, Order $order)
    {
        $order->update(['statusid' => $request->newStatus]);
        $order->details()->update(['statusid' => $request->newStatus]);
        return back()->with('success', 'Order status updated successfully');
    }
}
