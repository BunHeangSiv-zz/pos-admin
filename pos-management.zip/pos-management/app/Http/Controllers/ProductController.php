<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Status;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::with(['category', 'supplier', 'status'])
        ->orderBy('created_at', 'desc')
        ->get();
        $products = $products->map(function ($product) {
            return [
                'id' => $product->productid,
                'productname' => $product->productname,
                'categoryname' => $product->category->categoryname,
                'suppliername' => $product->supplier->suppliername,
                'quantity' => $product->quantity,
                'pricein' => $product->pricein,
                'priceout' => $product->priceout,
                'instock' => $product->instock,
                'productimage' => $product->productimage,
                'productdate' => $product->productdate,
                'statusname' => $product->status->statusname
            ];
        });
        return response()->json($products);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'productname' => 'required|string|max:255',
            'categoryname' => 'required|exists:tblcategory,categoryname',
            'suppliername' => 'required|exists:tblsupplier,suppliername',
            'quantity' => 'required|integer',
            'pricein' => 'required|numeric',
            'priceout' => 'required|numeric',
            'instock' => 'required|integer',
            'productimage' => 'required|string|max:255',
            'statusname' => 'required|exists:tblstatus,statusname'
        ]);

        $category = Category::where('categoryname', $request->categoryname)->first();
        $supplier = Supplier::where('suppliername', $request->suppliername)->first();
        $status = Status::where('statusname', $request->statusname)->first();

        $product = Product::create([
            'productname' => $validated['productname'],
            'categoryid' => $category->categoryid,
            'supplierid' => $supplier->supplierid,
            'quantity' => $validated['quantity'],
            'pricein' => $validated['pricein'],
            'priceout' => $validated['priceout'],
            'instock' => $validated['instock'],
            'productimage' => $validated['productimage'],
            'statusid' => $status->statusid,
        ]);

        return response()->json($product, 201);
    }

    public function show($id)
    {
        $product = Product::with(['category', 'supplier', 'status'])->find($id);
        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }

        $productDetails = [
            'id' => $product->productid,
            'productname' => $product->productname,
            'categoryname' => $product->category->categoryname,
            'suppliername' => $product->supplier->suppliername,
            'quantity' => $product->quantity,
            'pricein' => $product->pricein,
            'priceout' => $product->priceout,
            'instock' => $product->instock,
            'productimage' => $product->productimage,
            'productdate' => $product->productdate,
            'statusname' => $product->status->statusname
        ];

        return response()->json($productDetails);
    }

    public function update(Request $request, $id)
    {
        $product = Product::find($id);
        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }

        $validated = Validator::make($request->all(), [
            'productname' => 'sometimes|required|string|max:255',
            'categoryname' => 'sometimes|required|exists:tblcategory,categoryname',
            'suppliername' => 'sometimes|required|exists:tblsupplier,suppliername',
            'quantity' => 'sometimes|required|integer',
            'pricein' => 'sometimes|required|numeric',
            'priceout' => 'sometimes|required|numeric',
            'instock' => 'sometimes|required|integer',
            'productimage' => 'sometimes|required|string|max:255',
            'productdate' => 'nullable|date',
            'statusname' => 'sometimes|required|exists:tblstatus,statusname'
        ]);

        if ($validated->fails()) {
            return response()->json(['errors' => $validated->errors()], 422);
        }

        $data = $validated->validated();

        if (isset($data['categoryname'])) {
            $category = Category::where('categoryname', $request->categoryname)->first();
            $data['categoryid'] = $category->categoryid;
            unset($data['categoryname']);
        }

        if (isset($data['suppliername'])) {
            $supplier = Supplier::where('suppliername', $request->suppliername)->first();
            $data['supplierid'] = $supplier->supplierid;
            unset($data['suppliername']);
        }

        if (isset($data['statusname'])) {
            $status = Status::where('statusname', $request->statusname)->first();
            $data['statusid'] = $status->statusid;
            unset($data['statusname']);
        }

        $product->update($data);

        return response()->json($product);
    }

    public function destroy($id)
    {
        $product = Product::find($id);
        if (!$product) {
            return response()->json(['message' => 'Product not found'], 404);
        }
        $product->delete();
        return response()->json(['message' => 'Product deleted']);
    }

    public function soldProducts()
{
    $soldProducts = DB::table('tblorderdetail')
                        ->join('tblproduct', 'tblorderdetail.productid', '=', 'tblproduct.productid')
                        ->select('tblproduct.productname', 'tblproduct.productid', DB::raw('SUM(tblorderdetail.quantity) as total_quantity'), DB::raw('SUM(tblorderdetail.unitprice * tblorderdetail.quantity) as total_sales'))
                        ->groupBy('tblproduct.productname', 'tblproduct.productid')
                        ->orderBy('total_quantity', 'desc')
                        ->get();

    return view('products.sold', compact('soldProducts'));
}

}
