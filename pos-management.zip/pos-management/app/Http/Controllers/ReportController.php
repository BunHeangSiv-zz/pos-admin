<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class ReportController extends Controller
{
    public function salesReport()
    {
        $salesData = Order::with('details')->get()->groupBy('employeeid')->map(function ($item) {
            return $item->sum('totalamount');
        });
        return view('reports.sales', compact('salesData'));
    }
}
