<?php

namespace App\Http\Controllers;

use App\Models\InventoryLog;
use App\Models\Order;
use App\Models\OrderDetail;
use Illuminate\Http\Request;

class SalesController extends Controller
{

    public function getOrders()
    {
        $orders = Order::with('orderDetails')->get();

        return response()->json($orders);
    }

    public function getOrderById($id)
{
    $order = Order::with('orderDetails')->find($id);

    if (!$order) {
        return response()->json(['message' => 'Order not found'], 404);
    }

    return response()->json($order);
}
    public function createOrder(Request $request)
    {
        $order = Order::create($request->all());

        foreach ($request->orderDetails as $detail) {
            $detail['orderid'] = $order->orderid;
            OrderDetail::create($detail);

            // Update inventory
            InventoryLog::create([
                'productid' => $detail['productid'],
                'changeamount' => -$detail['quantity'],
                'changedate' => now(),
                'reason' => 'Order Placed',
                'statusid' => 1 // Assuming '1' is active
            ]);
        }

        return response()->json(['message' => 'Order created successfully!', 'order' => $order], 201);
    }
    
    public function store(Request $request)
{
    try {
        $order = new Order();
        $order->customer_id = $request->customerid;
        $order->save();

        foreach ($request->orderDetails as $detail) {
            $orderDetail = new OrderDetail();
            $orderDetail->order_id = $order->id;
            $orderDetail->product_id = $detail['productid'];
            $orderDetail->quantity = $detail['quantity'];
            $orderDetail->unit_price = $detail['unitprice'];
            $orderDetail->save();
        }

        return response()->json(['message' => 'Order created successfully!', 'order' => $order], 201);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
}

}

