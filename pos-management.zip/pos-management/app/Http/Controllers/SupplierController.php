<?php

namespace App\Http\Controllers;

use App\Models\Supplier;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    // GET: List all suppliers
    public function index()
    {
        $suppliers = Supplier::all();
        return response()->json($suppliers);
    }

    // POST: Create a new supplier
    public function store(Request $request)
    {
        $validated = $request->validate([
            'suppliername' => 'required',
            'contactname' => 'required',
            'contacttitle' => 'required',
            'address' => 'required',
            'phonenumber' => 'required',
            'email' => 'required|email',
            'website' => 'required',
            'telegram' => 'required',
            'photo' => 'required',
            'statusid' => 'required|int'  // Validating as an integer
        ]);

        $supplier = Supplier::create($validated);
        return response()->json($supplier, 201);
    }

    // GET: Show a specific supplier
    public function show($id)
    {
        $supplier = Supplier::find($id);
        if (!$supplier) {
            return response()->json(['message' => 'Supplier not found'], 404);
        }
        return response()->json($supplier);
    }

    // PUT: Update a supplier
    public function update(Request $request, $id)
    {
        $supplier = Supplier::find($id);
        if (!$supplier) {
            return response()->json(['message' => 'Supplier not found'], 404);
        }
        $supplier->update($request->all());
        return response()->json($supplier);
    }

    // DELETE: Delete a supplier
    public function destroy($id)
    {
        $supplier = Supplier::find($id);
        if (!$supplier) {
            return response()->json(['message' => 'Supplier not found'], 404);
        }
        $supplier->delete();
        return response()->json(['message' => 'Supplier deleted']);
    }
}
