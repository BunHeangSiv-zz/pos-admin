<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $table = 'tblcustomer';
    protected $primaryKey = 'customerid';
    public $timestamps = false; // Assuming no created_at and updated_at columns
    protected $fillable = [
        'customername', 'sexid',
        'address', 'phonenumber', 'statusid'
    ];
    public function sex()
    {
        return $this->hasOne(Sex::class);
    }
}

