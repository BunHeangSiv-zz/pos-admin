<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $table = 'tblemployee';
    protected $primaryKey = 'employeeid';
    public $timestamps = false; // Adjust based on your table structure

    protected $fillable = [
        'employeename', 'positionid', 'sexid', 'dob', 'address',
        'phonenumber', 'email', 'telegram', 'photo', 'statusid'  // Include statusid here
    ];

    public function sex()
    {
        return $this->belongsTo(Sex::class, 'sexid', 'sexid');
    }

    public function position()
    {
        return $this->belongsTo(Position::class, 'positionid', 'positionid');
    }
}
