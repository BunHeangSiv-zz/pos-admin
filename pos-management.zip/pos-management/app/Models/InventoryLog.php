<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InventoryLog extends Model
{
    protected $table = 'tblinventorylog';
    protected $fillable = ['productid', 'changeamount', 'changedate', 'reason', 'statusid'];
    public $timestamps = false; 
}
