<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'tblorder';
    protected $fillable = ['orderdate', 'employeeid', 'customerid', 'discount', 'totalamount', 'statusid'];
    public $timestamps = false;
    public function details()
    {
        return $this->hasMany(OrderDetail::class, 'orderid');
    }
}
