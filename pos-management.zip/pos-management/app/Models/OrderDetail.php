<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderDetail extends Model
{
    protected $table = 'tblorderdetail';
    protected $fillable = ['orderid', 'productid', 'quantity', 'unitprice', 'discount', 'statusid'];
    public $timestamps = false; 
}
