<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $table = 'tblproduct';
    protected $primaryKey = 'productid';  // Specify the primary key here
    protected $fillable = [
        'productname', 'categoryid', 'supplierid', 'quantity', 'pricein', 'priceout', 'instock', 'productimage', 'statusid'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class, 'categoryid');
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class, 'supplierid');
    }

    public function status()
    {
        return $this->belongsTo(Status::class,'statusid');
    }
}
