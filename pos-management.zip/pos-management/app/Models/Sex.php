<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sex extends Model
{
    protected $table = 'tblsex';
    protected $primaryKey = 'sexid';  // Specify the primary key here

    public $timestamps = false; // Adjust based on your table structure
}
