<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $table = 'tblsupplier';  // Specify the custom table name
    protected $primaryKey ='supplierid'; // Specify the primary key column name

    protected $fillable = [
        'suppliername', 'contactname', 'contacttitle', 'address',
        'phonenumber', 'email', 'website', 'telegram', 'photo', 'statusid'
    ];

    public $timestamps = false; // Adjust based on your table, assuming no timestamps
}
