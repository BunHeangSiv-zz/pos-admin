<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddDefaultStatusToTblorderdetail extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('tblorderdetail', function (Blueprint $table) {
            // Change the column to set a default value
            $table->integer('statusid')->default(1)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('tblorderdetail', function (Blueprint $table) {
            // Remove the default value. Assume it was nullable or had a different default.
            $table->integer('statusid')->nullable()->change();
        });
    }
}
