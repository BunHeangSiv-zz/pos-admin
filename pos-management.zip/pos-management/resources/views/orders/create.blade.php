{{-- resources/views/orders/create.blade.php --}}
@extends('layouts.app')

@section('content')
<div>
    <button><a href="/products/sold">Sale Report</a></button>
    <button><a href="/reports/sales">Employee earn Report</a></button>
</div>

<br>
<form action="{{ route('orders.store') }}" method="POST">
    @csrf
    <label for="employeeid">Employee:</label>
    <select name="employeeid" id="employeeid" required>
        @foreach ($employees as $employee)
            <option value="{{ $employee->employeeid }}">{{ $employee->employeename }}</option>
        @endforeach
    </select>

    <label for="customerid">Customer:</label>
    <select name="customerid" id="customerid" required>
        @foreach ($customers as $customer)
            <option value="{{ $customer->customerid }}">{{ $customer->customername }}</option>
        @endforeach
    </select>

    <label for="statusid">Status:</label>
    <select name="statusid" id="statusid" required>
        @foreach ($statuses as $status)
            <option value="{{ $status->statusid }}">{{ $status->statusname }}</option>
        @endforeach
    </select>

    <div id="product-details">
        <div class="product-item">
            <label for="productid">Product:</label>
            <select name="productid[]" class="productid" required onchange="updatePrice(this)">
                @foreach ($products as $product)
                    <option value="{{ $product->productid }}" data-price="{{ $product->priceout }}">{{ $product->productname }}</option>
                @endforeach
            </select>

            <label for="quantity[]">Quantity:</label>
            <input type="number" name="quantity[]" class="quantity" required onchange="updateTotal()">

            <label for="unitprice[]">Unit Price:</label>
            <input type="text" name="unitprice[]" class="unitprice" readonly>
            <button type="button" class="remove-product-btn" onclick="removeProduct(this)">Remove Product</button>

        </div>
    </div>
    <button type="button" onclick="addProduct()">Add Another Product</button>

    <label for="totalamount">Total Amount:</label>
    <input type="text" name="totalamount" id="totalamount" readonly>

    <button type="submit">Submit Order</button>
</form>

<script>
    function updatePrice(select) {
        let price = select.options[select.selectedIndex].getAttribute('data-price');
        select.closest('.product-item').querySelector('.unitprice').value = price;
        updateTotal();
    }

    function addProduct() {
        const container = document.getElementById('product-details');
        const original = document.querySelector('.product-item');
        const clone = original.cloneNode(true);
        clone.querySelector('.productid').selectedIndex = 0;
        clone.querySelector('.quantity').value = '';
        clone.querySelector('.unitprice').value = '';
        clone.querySelector('.remove-product-btn').onclick = function() { removeProduct(this); };
        container.appendChild(clone);
    }

    function removeProduct(button) {
        const item = button.closest('.product-item');
        item.remove();
        updateTotal();
    }

    function updateTotal() {
        let total = 0;
        document.querySelectorAll('.product-item').forEach(item => {
            let price = parseFloat(item.querySelector('.unitprice').value) || 0;
            let quantity = parseInt(item.querySelector('.quantity').value) || 0;
            total += price * quantity;
        });
        document.getElementById('totalamount').value = total.toFixed(2);
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.productid').forEach(select => {
            select.dispatchEvent(new Event('change'));
        });
    });
    </script>
@endsection
