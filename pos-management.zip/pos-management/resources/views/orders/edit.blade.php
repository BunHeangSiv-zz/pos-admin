{{-- update-status.blade.php --}}
@extends('layouts.app')

@section('content')
<form action="{{ route('orders.updateStatus', $order->id) }}" method="POST">
    @csrf
    @method('PATCH')
    <h2>Update Order Status</h2>
    <div>
        <label for="newStatus">New Status:</label>
        <select name="newStatus" required>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="dispatched">Dispatched</option>
            <option value="cancelled">Cancelled</option>
        </select>
    </div>
    <button type="submit">Update Status</button>
</form>
@endsection
