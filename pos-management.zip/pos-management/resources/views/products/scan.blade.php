<div class="container">
    <h1>Scan QR Codes</h1>
    <div class="section">
        <div id="my-qr-reader">
        </div>
    </div>
</div>
<div class="row">
    {!! QrCode::size(100)->generate('P0001') !!}
    {!! QrCode::size(200)->generate('P0002') !!}
    {!! QrCode::size(200)->generate('P0003') !!}
</div>


<script src="https://unpkg.com/html5-qrcode"></script>
<script>

function domReady(fn) {
if (
    document.readyState === "complete" ||
    document.readyState === "interactive"
) {
    setTimeout(fn, 1000);
} else {
    document.addEventListener("DOMContentLoaded", fn);
}
}

domReady(function () {

// If found you qr code
function onScanSuccess(decodeText, decodeResult) {

   alert("You Qr is : " + decodeText, decodeResult);

}

let htmlscanner = new Html5QrcodeScanner(
    "my-qr-reader",
    { fps: 10, qrbos: 250 }
);
htmlscanner.render(onScanSuccess);
});
</script>
