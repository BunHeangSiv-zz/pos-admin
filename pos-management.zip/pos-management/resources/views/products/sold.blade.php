@extends('layouts.app')

@section('content')
    <h1>Sold Products Report</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Total Quantity Sold</th>
                <th>Total Sales</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($soldProducts as $product)
                <tr>
                    <td>{{ $product->productid }}</td>
                    <td>{{ $product->productname }}</td>
                    <td>{{ $product->total_quantity }}</td>
                    <td>${{ number_format($product->total_sales, 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <div>
        <a href="/orders/create">Sale more</a>
    </div>
@endsection
