{{-- sales-report.blade.php --}}
@extends('layouts.app')

@section('content')
<h2>Sales Report</h2>
<table>
    <thead>
        <tr>
            <th>Employee ID</th>
            <th>Total Sales</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($salesData as $employeename => $totalSales)
            <tr>
                <td>{{ $employeename }}</td>
                <td>{{ $totalSales }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
@endsection
