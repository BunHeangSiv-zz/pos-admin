
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> <!-- Ensure you have this CSS file or link your own -->
    <title>POS Management System</title>
</head>
<body>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script> <!-- Ensure you have this JS file or link your own -->
</body>
</html>
<?php /**PATH /Users/macbookpro/Documents/class-web_api/pos-management/resources/views/layouts/app.blade.php ENDPATH**/ ?>