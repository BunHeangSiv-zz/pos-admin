<?php $__env->startSection('content'); ?>
<div>
    <button><a href="/products/sold">Sale Report</a></button>
    <button><a href="/reports/sales">Employee earn Report</a></button>
</div>

<br>
<form action="<?php echo e(route('orders.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="employeeid">Employee:</label>
    <select name="employeeid" id="employeeid" required>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($employee->employeeid); ?>"><?php echo e($employee->employeename); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="customerid">Customer:</label>
    <select name="customerid" id="customerid" required>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($customer->customerid); ?>"><?php echo e($customer->customername); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="statusid">Status:</label>
    <select name="statusid" id="statusid" required>
        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($status->statusid); ?>"><?php echo e($status->statusname); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <div id="product-details">
        <div class="product-item">
            <label for="productid">Product:</label>
            <select name="productid[]" class="productid" required onchange="updatePrice(this)">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->productid); ?>" data-price="<?php echo e($product->priceout); ?>"><?php echo e($product->productname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="quantity[]">Quantity:</label>
            <input type="number" name="quantity[]" class="quantity" required onchange="updateTotal()">

            <label for="unitprice[]">Unit Price:</label>
            <input type="text" name="unitprice[]" class="unitprice" readonly>
            <button type="button" class="remove-product-btn" onclick="removeProduct(this)">Remove Product</button>

        </div>
    </div>
    <button type="button" onclick="addProduct()">Add Another Product</button>

    <label for="totalamount">Total Amount:</label>
    <input type="text" name="totalamount" id="totalamount" readonly>

    <button type="submit">Submit Order</button>
</form>

<script>
    function updatePrice(select) {
        let price = select.options[select.selectedIndex].getAttribute('data-price');
        select.closest('.product-item').querySelector('.unitprice').value = price;
        updateTotal();
    }

    function addProduct() {
        const container = document.getElementById('product-details');
        const original = document.querySelector('.product-item');
        const clone = original.cloneNode(true);
        clone.querySelector('.productid').selectedIndex = 0;
        clone.querySelector('.quantity').value = '';
        clone.querySelector('.unitprice').value = '';
        clone.querySelector('.remove-product-btn').onclick = function() { removeProduct(this); };
        container.appendChild(clone);
    }

    function removeProduct(button) {
        const item = button.closest('.product-item');
        item.remove();
        updateTotal();
    }

    function updateTotal() {
        let total = 0;
        document.querySelectorAll('.product-item').forEach(item => {
            let price = parseFloat(item.querySelector('.unitprice').value) || 0;
            let quantity = parseInt(item.querySelector('.quantity').value) || 0;
            total += price * quantity;
        });
        document.getElementById('totalamount').value = total.toFixed(2);
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.productid').forEach(select => {
            select.dispatchEvent(new Event('change'));
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Documents/class-web_api/pos-management/resources/views/orders/create.blade.php ENDPATH**/ ?>