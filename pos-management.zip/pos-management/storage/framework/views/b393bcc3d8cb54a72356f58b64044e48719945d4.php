<?php $__env->startSection('content'); ?>
    <h1>Sold Products Report</h1>
    <table class="table">
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Total Quantity Sold</th>
                <th>Total Sales</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $soldProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->productid); ?></td>
                    <td><?php echo e($product->productname); ?></td>
                    <td><?php echo e($product->total_quantity); ?></td>
                    <td>$<?php echo e(number_format($product->total_sales, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div>
        <a href="/orders/create">Sale more</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Documents/class-web_api/pos-management/resources/views/products/sold.blade.php ENDPATH**/ ?>