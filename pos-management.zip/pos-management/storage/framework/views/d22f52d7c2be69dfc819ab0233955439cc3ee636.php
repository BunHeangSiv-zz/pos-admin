<?php $__env->startSection('content'); ?>
<h2>Sales Report</h2>
<table>
    <thead>
        <tr>
            <th>Employee ID</th>
            <th>Total Sales</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $salesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeename => $totalSales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($employeename); ?></td>
                <td><?php echo e($totalSales); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Documents/class-web_api/pos-management/resources/views/reports/sales.blade.php ENDPATH**/ ?>